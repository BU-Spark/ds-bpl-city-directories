import collections,csv,hashlib,json,pathlib
p=pathlib.Path('output'); people=json.loads((p/'people.json').read_text()); audit=json.loads((p/'unresolved_and_nonperson.json').read_text());rows=json.loads((p/'source_ocr_lines.json').read_text()); byid={r['id']:r for r in rows}
for stem in ['people','unresolved_and_nonperson','source_ocr_lines']:
 js=json.loads((p/(stem+'.json')).read_text())
 with (p/(stem+'.csv')).open(encoding='utf-8-sig',newline='') as f: cs=list(csv.DictReader(f))
 assert len(js)==len(cs)
 for a,b in zip(js,cs):
  for k,v in a.items():
   expected=json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else '' if v is None else str(v)
   assert b[k]==expected,(stem,k)
for model,key in [('Tesseract','t'),('DOTS.MOCR','m')]:
 rec=[r for r in people+audit if r['ocr_model']==model]
 assert collections.Counter(r['source_line_ids'][0] for r in rec)==collections.Counter(byid.keys())
 for r in rec:
  assert r['original_ocr_text']=='\n'.join(byid[i][key] for i in r['source_line_ids'])
  assert all(byid[i]['page']==r['source_page'] for i in r['source_line_ids'])
  assert r['latitude'] is None and r['longitude'] is None
  if r['home_address']:assert r['residence_marker'] in ['h','bds','rms']
  if 'surname_context_without_ditto_requires_review' in r['flags']:assert r['name'] is None
source=next(pathlib.Path('attachments').glob('*/index.html'))
assert source.read_bytes()==(p/'index.html').read_bytes()
# Representative residence/work/relationship distinctions and abstention cases.
t={r['record_id']:r for r in people}
assert t['t-0018']['work_address']=='40 Court rm 1002'
assert t['t-0018']['home_address']=='1254 Commonwealth av'
assert t['t-0018']['name']=='Aaron David J'
assert t['t-0027']['home_address']=='at Stoneham'
assert t['t-0027']['address_for_geocoding']=='Stoneham'
assert t['m-0015']['name'] is None # merged OCR: multiple residence markers
assert t['t-0015']['home_address_geocoding'] is None # truncated Warren
print('PASS: CSV/JSON field equivalence; every source line/model covered; exact OCR provenance; unchanged HTML; representative work/home, ditto-name, locality-only, merged and truncated cases.')
